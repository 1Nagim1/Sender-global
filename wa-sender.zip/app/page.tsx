"use client"

import  from "../backend/src/index"

export default function SyntheticV0PageForDeployment() {
  return < />
}