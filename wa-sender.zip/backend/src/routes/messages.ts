import express from "express"
import { supabase } from "../services/database"
import { logger } from "../utils/logger"

const router = express.Router()

// Extract variables from message content
function extractVariables(content: string): string[] {
  const regex = /\{([^}]+)\}/g
  const variables = []
  let match

  while ((match = regex.exec(content)) !== null) {
    variables.push(match[1])
  }

  return [...new Set(variables)] // Remove duplicates
}

// Get all message templates
router.get("/", async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("message_templates")
      .select("*")
      .order("createdAt", { ascending: false })

    if (error) {
      throw error
    }

    res.json(data)
  } catch (error) {
    logger.error("Error fetching message templates:", error)
    res.status(500).json({ error: "Failed to fetch message templates" })
  }
})

// Get message template by ID
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params
    const { data, error } = await supabase.from("message_templates").select("*").eq("id", id).single()

    if (error) {
      throw error
    }

    if (!data) {
      return res.status(404).json({ error: "Message template not found" })
    }

    res.json(data)
  } catch (error) {
    logger.error(`Error fetching message template ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to fetch message template" })
  }
})

// Create new message template
router.post("/", async (req, res) => {
  try {
    const { name, content } = req.body

    if (!name || !content) {
      return res.status(400).json({ error: "Name and content are required" })
    }

    // Extract variables from content
    const variables = extractVariables(content)

    // Create message template in database
    const { data, error } = await supabase
      .from("message_templates")
      .insert({
        name,
        content,
        variables,
      })
      .select()
      .single()

    if (error) {
      throw error
    }

    res.status(201).json(data)
  } catch (error) {
    logger.error("Error creating message template:", error)
    res.status(500).json({ error: "Failed to create message template" })
  }
})

// Update message template
router.put("/:id", async (req, res) => {
  try {
    const { id } = req.params
    const { name, content } = req.body

    const updates: any = {}
    if (name) updates.name = name
    if (content) {
      updates.content = content
      updates.variables = extractVariables(content)
    }

    const { data, error } = await supabase.from("message_templates").update(updates).eq("id", id).select().single()

    if (error) {
      throw error
    }

    if (!data) {
      return res.status(404).json({ error: "Message template not found" })
    }

    res.json(data)
  } catch (error) {
    logger.error(`Error updating message template ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to update message template" })
  }
})

// Delete message template
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params

    const { error } = await supabase.from("message_templates").delete().eq("id", id)

    if (error) {
      throw error
    }

    res.status(204).send()
  } catch (error) {
    logger.error(`Error deleting message template ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to delete message template" })
  }
})

export default router
