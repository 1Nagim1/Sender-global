import express from "express"
import { supabase } from "../services/database"
import { logger } from "../utils/logger"
import { sendToQueue, QUEUE_CHECKS } from "../services/rabbitmq"

const router = express.Router()

// Validate phone number
function isValidPhone(phone: string): boolean {
  // Simple validation for demonstration
  // In a real app, this would be more sophisticated
  return /^\d{10,15}$/.test(phone)
}

// Get all contacts
router.get("/", async (req, res) => {
  try {
    const { data, error } = await supabase.from("contacts").select("*").order("createdAt", { ascending: false })

    if (error) {
      throw error
    }

    res.json(data)
  } catch (error) {
    logger.error("Error fetching contacts:", error)
    res.status(500).json({ error: "Failed to fetch contacts" })
  }
})

// Get contact by ID
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params
    const { data, error } = await supabase.from("contacts").select("*").eq("id", id).single()

    if (error) {
      throw error
    }

    if (!data) {
      return res.status(404).json({ error: "Contact not found" })
    }

    res.json(data)
  } catch (error) {
    logger.error(`Error fetching contact ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to fetch contact" })
  }
})

// Create new contact
router.post("/", async (req, res) => {
  try {
    const { phone, name } = req.body

    if (!phone) {
      return res.status(400).json({ error: "Phone number is required" })
    }

    if (!isValidPhone(phone)) {
      return res.status(400).json({ error: "Invalid phone number format" })
    }

    // Check if contact already exists
    const { data: existingContact } = await supabase.from("contacts").select("id").eq("phone", phone).single()

    if (existingContact) {
      return res.status(409).json({ error: "Contact with this phone number already exists" })
    }

    // Create contact in database
    const { data, error } = await supabase
      .from("contacts")
      .insert({
        phone,
        name: name || null,
      })
      .select()
      .single()

    if (error) {
      throw error
    }

    res.status(201).json(data)
  } catch (error) {
    logger.error("Error creating contact:", error)
    res.status(500).json({ error: "Failed to create contact" })
  }
})

// Update contact
router.put("/:id", async (req, res) => {
  try {
    const { id } = req.params
    const { name, phone } = req.body

    const updates: any = {}
    if (name !== undefined) updates.name = name
    if (phone) {
      if (!isValidPhone(phone)) {
        return res.status(400).json({ error: "Invalid phone number format" })
      }
      updates.phone = phone
    }

    const { data, error } = await supabase.from("contacts").update(updates).eq("id", id).select().single()

    if (error) {
      throw error
    }

    if (!data) {
      return res.status(404).json({ error: "Contact not found" })
    }

    res.json(data)
  } catch (error) {
    logger.error(`Error updating contact ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to update contact" })
  }
})

// Delete contact
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params

    const { error } = await supabase.from("contacts").delete().eq("id", id)

    if (error) {
      throw error
    }

    res.status(204).send()
  } catch (error) {
    logger.error(`Error deleting contact ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to delete contact" })
  }
})

// Check if contact has WhatsApp
router.post("/:id/check", async (req, res) => {
  try {
    const { id } = req.params

    // Get contact details
    const { data: contact, error: fetchError } = await supabase.from("contacts").select("id").eq("id", id).single()

    if (fetchError || !contact) {
      return res.status(404).json({ error: "Contact not found" })
    }

    // Get active instance for checking
    const { data: instance, error: instanceError } = await supabase
      .from("instances")
      .select("id, instanceId, token")
      .eq("status", "active")
      .limit(1)
      .single()

    if (instanceError || !instance) {
      return res.status(400).json({ error: "No active instance available for checking" })
    }

    // Send check request to queue
    await sendToQueue(QUEUE_CHECKS, {
      contactId: id,
      instanceId: instance.instanceId,
      token: instance.token,
    })

    // Emit log via Socket.IO
    if (req.io) {
      req.io.emit("log", {
        type: "info",
        message: `Запрос на проверку WhatsApp отправлен`,
        timestamp: new Date(),
      })
    }

    res.json({ message: "Check request queued" })
  } catch (error) {
    logger.error(`Error checking WhatsApp for contact ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to check WhatsApp status" })
  }
})

// Bulk import contacts
router.post("/bulk", async (req, res) => {
  try {
    const { contacts } = req.body

    if (!contacts) {
      return res.status(400).json({ error: "Contacts data is required" })
    }

    // Parse contacts from CSV or line-by-line format
    const lines = contacts.split("\n").filter(Boolean)
    const parsedContacts = []
    const errors = []
    let successCount = 0
    let failedCount = 0

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim()
      if (!line) continue

      // Parse line (format: phone,name)
      const parts = line.split(",")
      const phone = parts[0]?.trim()
      const name = parts[1]?.trim() || null

      if (!phone || !isValidPhone(phone)) {
        errors.push(`Line ${i + 1}: Invalid phone number format`)
        failedCount++
        continue
      }

      parsedContacts.push({ phone, name })
    }

    // Insert valid contacts
    if (parsedContacts.length > 0) {
      const { data, error } = await supabase
        .from("contacts")
        .upsert(
          parsedContacts.map((c) => ({ phone: c.phone, name: c.name })),
          { onConflict: "phone", ignoreDuplicates: true },
        )
        .select()

      if (error) {
        throw error
      }

      successCount = data?.length || 0
    }

    // Emit log via Socket.IO
    if (req.io) {
      req.io.emit("log", {
        type: successCount > 0 ? "success" : "warning",
        message: `Импортировано ${successCount} из ${parsedContacts.length} контактов`,
        timestamp: new Date(),
      })
    }

    res.json({
      total: parsedContacts.length + failedCount,
      success: successCount,
      failed: failedCount,
      errors,
    })
  } catch (error) {
    logger.error("Error importing contacts:", error)
    res.status(500).json({ error: "Failed to import contacts" })
  }
})

export default router
