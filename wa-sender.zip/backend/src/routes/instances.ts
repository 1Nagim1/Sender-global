import express from "express"
import { supabase } from "../services/database"
import { getInstanceStatus } from "../services/greenapi"
import { logger } from "../utils/logger"

const router = express.Router()

// Get all instances
router.get("/", async (req, res) => {
  try {
    const { data, error } = await supabase.from("instances").select("*").order("createdAt", { ascending: false })

    if (error) {
      throw error
    }

    res.json(data)
  } catch (error) {
    logger.error("Error fetching instances:", error)
    res.status(500).json({ error: "Failed to fetch instances" })
  }
})

// Get instance by ID
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params
    const { data, error } = await supabase.from("instances").select("*").eq("id", id).single()

    if (error) {
      throw error
    }

    if (!data) {
      return res.status(404).json({ error: "Instance not found" })
    }

    res.json(data)
  } catch (error) {
    logger.error(`Error fetching instance ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to fetch instance" })
  }
})

// Create new instance
router.post("/", async (req, res) => {
  try {
    const { instanceId, token, name } = req.body

    if (!instanceId || !token) {
      return res.status(400).json({ error: "Instance ID and token are required" })
    }

    // Check if instance is valid
    const status = await getInstanceStatus(instanceId, token)

    // Create instance in database
    const { data, error } = await supabase
      .from("instances")
      .insert({
        instanceId,
        token,
        name: name || `Instance ${instanceId}`,
        status: status.active ? "active" : "error",
      })
      .select()
      .single()

    if (error) {
      throw error
    }

    // Emit log via Socket.IO
    if (req.io) {
      req.io.emit("log", {
        type: status.active ? "success" : "warning",
        message: status.active
          ? `Инстанс ${instanceId} успешно добавлен`
          : `Инстанс ${instanceId} добавлен, но не активен`,
        timestamp: new Date(),
      })
    }

    res.status(201).json(data)
  } catch (error) {
    logger.error("Error creating instance:", error)
    res.status(500).json({ error: "Failed to create instance" })
  }
})

// Update instance
router.put("/:id", async (req, res) => {
  try {
    const { id } = req.params
    const { name, token } = req.body

    const updates: any = {}
    if (name) updates.name = name
    if (token) updates.token = token

    const { data, error } = await supabase.from("instances").update(updates).eq("id", id).select().single()

    if (error) {
      throw error
    }

    if (!data) {
      return res.status(404).json({ error: "Instance not found" })
    }

    res.json(data)
  } catch (error) {
    logger.error(`Error updating instance ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to update instance" })
  }
})

// Delete instance
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params

    const { error } = await supabase.from("instances").delete().eq("id", id)

    if (error) {
      throw error
    }

    // Emit log via Socket.IO
    if (req.io) {
      req.io.emit("log", {
        type: "info",
        message: `Инстанс удален`,
        timestamp: new Date(),
      })
    }

    res.status(204).send()
  } catch (error) {
    logger.error(`Error deleting instance ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to delete instance" })
  }
})

// Check instance status
router.post("/:id/check", async (req, res) => {
  try {
    const { id } = req.params

    // Get instance details
    const { data: instance, error: fetchError } = await supabase
      .from("instances")
      .select("instanceId, token")
      .eq("id", id)
      .single()

    if (fetchError || !instance) {
      return res.status(404).json({ error: "Instance not found" })
    }

    // Check instance status
    const status = await getInstanceStatus(instance.instanceId, instance.token)

    // Update instance status in database
    const { error: updateError } = await supabase
      .from("instances")
      .update({
        status: status.active ? "active" : "error",
        lastChecked: new Date().toISOString(),
      })
      .eq("id", id)

    if (updateError) {
      throw updateError
    }

    // Emit log via Socket.IO
    if (req.io) {
      req.io.emit("log", {
        type: status.active ? "success" : "error",
        message: status.active
          ? `Инстанс ${instance.instanceId} активен`
          : `Инстанс ${instance.instanceId} не активен: ${status.error}`,
        timestamp: new Date(),
      })
    }

    res.json({ active: status.active })
  } catch (error) {
    logger.error(`Error checking instance ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to check instance status" })
  }
})

export default router
