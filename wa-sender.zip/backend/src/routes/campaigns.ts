import express from "express"
import { supabase } from "../services/database"
import { logger } from "../utils/logger"
import { sendToQueue, QUEUE_MESSAGES } from "../services/rabbitmq"
import { v4 as uuidv4 } from "uuid"

const router = express.Router()

// Get all campaigns
router.get("/", async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("campaigns")
      .select(`
        *,
        messageTemplate:messageTemplateId (name)
      `)
      .order("createdAt", { ascending: false })

    if (error) {
      throw error
    }

    // Format response
    const formattedData = data.map((campaign) => ({
      ...campaign,
      messageTemplateName: campaign.messageTemplate?.name || "Unknown",
    }))

    res.json(formattedData)
  } catch (error) {
    logger.error("Error fetching campaigns:", error)
    res.status(500).json({ error: "Failed to fetch campaigns" })
  }
})

// Get campaign by ID
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params
    const { data, error } = await supabase
      .from("campaigns")
      .select(`
        *,
        messageTemplate:messageTemplateId (name, content, variables)
      `)
      .eq("id", id)
      .single()

    if (error) {
      throw error
    }

    if (!data) {
      return res.status(404).json({ error: "Campaign not found" })
    }

    // Format response
    const formattedData = {
      ...data,
      messageTemplateName: data.messageTemplate?.name || "Unknown",
    }

    res.json(formattedData)
  } catch (error) {
    logger.error(`Error fetching campaign ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to fetch campaign" })
  }
})

// Create new campaign
router.post("/", async (req, res) => {
  try {
    const { name, messageTemplateId, instanceIds, useRandomization = true, onlyWhatsappUsers = true } = req.body

    if (!name || !messageTemplateId || !instanceIds || instanceIds.length === 0) {
      return res.status(400).json({
        error: "Name, message template ID, and at least one instance ID are required",
      })
    }

    // Check if message template exists
    const { data: messageTemplate, error: templateError } = await supabase
      .from("message_templates")
      .select("id")
      .eq("id", messageTemplateId)
      .single()

    if (templateError || !messageTemplate) {
      return res.status(400).json({ error: "Message template not found" })
    }

    // Check if instances exist and are active
    const { data: instances, error: instancesError } = await supabase
      .from("instances")
      .select("id")
      .in("id", instanceIds)
      .eq("status", "active")

    if (instancesError) {
      throw instancesError
    }

    if (!instances || instances.length === 0) {
      return res.status(400).json({ error: "No valid active instances found" })
    }

    // Count total contacts
    const contactsQuery = supabase.from("contacts").select("count")

    if (onlyWhatsappUsers) {
      contactsQuery.eq("hasWhatsapp", true)
    }

    const { count: totalContacts, error: countError } = await contactsQuery

    if (countError) {
      throw countError
    }

    // Create campaign in database
    const { data, error } = await supabase
      .from("campaigns")
      .insert({
        name,
        messageTemplateId,
        instanceIds,
        useRandomization,
        onlyWhatsappUsers,
        totalContacts: totalContacts || 0,
        status: "draft",
      })
      .select()
      .single()

    if (error) {
      throw error
    }

    // Emit log via Socket.IO
    if (req.io) {
      req.io.emit("log", {
        type: "info",
        message: `Создана новая кампания: ${name}`,
        timestamp: new Date(),
      })
    }

    res.status(201).json(data)
  } catch (error) {
    logger.error("Error creating campaign:", error)
    res.status(500).json({ error: "Failed to create campaign" })
  }
})

// Delete campaign
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params

    // Check if campaign exists and is in a deletable state
    const { data: campaign, error: fetchError } = await supabase
      .from("campaigns")
      .select("status")
      .eq("id", id)
      .single()

    if (fetchError) {
      throw fetchError
    }

    if (!campaign) {
      return res.status(404).json({ error: "Campaign not found" })
    }

    if (campaign.status === "running") {
      return res.status(400).json({ error: "Cannot delete a running campaign" })
    }

    // Delete campaign
    const { error } = await supabase.from("campaigns").delete().eq("id", id)

    if (error) {
      throw error
    }

    // Emit log via Socket.IO
    if (req.io) {
      req.io.emit("log", {
        type: "info",
        message: `Кампания удалена`,
        timestamp: new Date(),
      })
    }

    res.status(204).send()
  } catch (error) {
    logger.error(`Error deleting campaign ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to delete campaign" })
  }
})

// Start campaign
router.post("/:id/start", async (req, res) => {
  try {
    const { id } = req.params

    // Get campaign details
    const { data: campaign, error: fetchError } = await supabase
      .from("campaigns")
      .select(`
        *,
        messageTemplate:messageTemplateId (content)
      `)
      .eq("id", id)
      .single()

    if (fetchError || !campaign) {
      return res.status(404).json({ error: "Campaign not found" })
    }

    if (campaign.status !== "draft" && campaign.status !== "paused") {
      return res.status(400).json({
        error: `Campaign cannot be started from ${campaign.status} status`,
      })
    }

    // Get instances for the campaign
    const { data: instances, error: instancesError } = await supabase
      .from("instances")
      .select("id, instanceId, token")
      .in("id", campaign.instanceIds)
      .eq("status", "active")

    if (instancesError) {
      throw instancesError
    }

    if (!instances || instances.length === 0) {
      return res.status(400).json({ error: "No active instances available for this campaign" })
    }

    // Get contacts
    const contactsQuery = supabase.from("contacts").select("id, phone, name")

    if (campaign.onlyWhatsappUsers) {
      contactsQuery.eq("hasWhatsapp", true)
    }

    const { data: contacts, error: contactsError } = await contactsQuery

    if (contactsError) {
      throw contactsError
    }

    if (!contacts || contacts.length === 0) {
      return res.status(400).json({ error: "No contacts available for this campaign" })
    }

    // Update campaign status
    const { error: updateError } = await supabase
      .from("campaigns")
      .update({
        status: "running",
        startedAt: new Date().toISOString(),
        totalContacts: contacts.length,
      })
      .eq("id", id)

    if (updateError) {
      throw updateError
    }

    // Create message logs and queue messages
    const messageTemplate = campaign.messageTemplate?.content || ""
    const useRandomization = campaign.useRandomization

    // Distribute contacts among instances
    const instanceCount = instances.length

    for (let i = 0; i < contacts.length; i++) {
      const contact = contacts[i]
      const instance = instances[i % instanceCount] // Round-robin distribution

      // Create message log
      const messageId = uuidv4()
      await supabase.from("message_logs").insert({
        id: messageId,
        campaignId: id,
        contactId: contact.id,
        instanceId: instance.id,
        status: "pending",
      })

      // Queue message
      await sendToQueue(QUEUE_MESSAGES, {
        messageId,
        campaignId: id,
        contactId: contact.id,
        instanceId: instance.instanceId,
        token: instance.token,
        text: messageTemplate,
        useRandomization,
      })
    }

    // Emit log via Socket.IO
    if (req.io) {
      req.io.emit("log", {
        type: "success",
        message: `Кампания "${campaign.name}" запущена, ${contacts.length} сообщений в очереди`,
        timestamp: new Date(),
      })
    }

    res.json({
      message: "Campaign started",
      contactsCount: contacts.length,
    })
  } catch (error) {
    logger.error(`Error starting campaign ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to start campaign" })
  }
})

// Pause campaign
router.post("/:id/pause", async (req, res) => {
  try {
    const { id } = req.params

    // Check if campaign exists and is running
    const { data: campaign, error: fetchError } = await supabase
      .from("campaigns")
      .select("status, name")
      .eq("id", id)
      .single()

    if (fetchError || !campaign) {
      return res.status(404).json({ error: "Campaign not found" })
    }

    if (campaign.status !== "running") {
      return res.status(400).json({ error: "Only running campaigns can be paused" })
    }

    // Update campaign status
    const { error: updateError } = await supabase
      .from("campaigns")
      .update({
        status: "paused",
      })
      .eq("id", id)

    if (updateError) {
      throw updateError
    }

    // Emit log via Socket.IO
    if (req.io) {
      req.io.emit("log", {
        type: "info",
        message: `Кампания "${campaign.name}" приостановлена`,
        timestamp: new Date(),
      })
    }

    res.json({ message: "Campaign paused" })
  } catch (error) {
    logger.error(`Error pausing campaign ${req.params.id}:`, error)
    res.status(500).json({ error: "Failed to pause campaign" })
  }
})

// Stop campaign
router.post('/:id/stop', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if campaign exists
    const { data: campaign, error: fetchError } = await supabase
      .from('campaigns')
      .select('status, name')
      .eq('id', id)
      .single();
    
    if (fetchError || !campaign) {
      return res.status(404).json({ error: 'Campaign not found' });
    }
    
    if (campaign.status !== 'running' && campaign.status !== 'paused') {
      return res.status(400).json({ error: 'Only running or paused campaigns can be stopped' });
    }
    
    // Update campaign status
    const { error: updateError } = await supabase
      .from('campaigns')
      .update({
        status: 'completed',
        completedAt: new Date().toISOString()
      })
