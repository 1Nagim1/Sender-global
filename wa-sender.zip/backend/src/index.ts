import express from "express"
import cors from "cors"
import dotenv from "dotenv"
import { createServer } from "http"
import { Server } from "socket.io"
import { connect as connectRabbitMQ } from "./services/rabbitmq"
import { setupWorker } from "./services/worker"
import { setupDatabase } from "./services/database"
import { logger } from "./utils/logger"
import instancesRouter from "./routes/instances"
import messagesRouter from "./routes/messages"
import contactsRouter from "./routes/contacts"
import campaignsRouter from "./routes/campaigns"
import analyticsRouter from "./routes/analytics"
import settingsRouter from "./routes/settings"

// Load environment variables
dotenv.config()

// Initialize Express app
const app = express()
const PORT = process.env.PORT || 3000

// Create HTTP server
const httpServer = createServer(app)

// Initialize Socket.IO
const io = new Server(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || "*",
    methods: ["GET", "POST"],
    credentials: true,
  },
})

// Middleware
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "*",
    credentials: true,
  }),
)
app.use(express.json())

// Pass io to routes via request object
app.use((req, res, next) => {
  req.io = io
  next()
})

// Routes
app.get("/api/status", (req, res) => {
  res.json({ status: "ok", timestamp: new Date() })
})

app.get("/api/stats", async (req, res) => {
  try {
    // This would normally come from the database
    // For now, we'll return mock data
    res.json({
      totalInstances: 3,
      activeInstances: 2,
      totalMessages: 1250,
      deliveredMessages: 1100,
      pendingMessages: 50,
      failedMessages: 100,
    })
  } catch (error) {
    logger.error("Error fetching stats:", error)
    res.status(500).json({ error: "Failed to fetch stats" })
  }
})

// API Routes
app.use("/api/instances", instancesRouter)
app.use("/api/messages", messagesRouter)
app.use("/api/contacts", contactsRouter)
app.use("/api/campaigns", campaignsRouter)
app.use("/api/analytics", analyticsRouter)
app.use("/api/settings", settingsRouter)

// Socket.IO connection handler
io.on("connection", (socket) => {
  logger.info(`Client connected: ${socket.id}`)

  // Send welcome message
  socket.emit("log", {
    type: "info",
    message: "Connected to WA-Sender server",
    timestamp: new Date(),
  })

  socket.on("disconnect", () => {
    logger.info(`Client disconnected: ${socket.id}`)
  })
})

// Initialize services and start server
async function startServer() {
  try {
    // Setup database connection
    await setupDatabase()
    logger.info("Database connection established")

    // Connect to RabbitMQ
    await connectRabbitMQ()
    logger.info("RabbitMQ connection established")

    // Setup worker
    await setupWorker()
    logger.info("Worker service initialized")

    // Start HTTP server
    httpServer.listen(PORT, () => {
      logger.info(`Server running on port ${PORT}`)
    })
  } catch (error) {
    logger.error("Failed to start server:", error)
    process.exit(1)
  }
}

startServer()

// Handle graceful shutdown
process.on("SIGTERM", () => {
  logger.info("SIGTERM received, shutting down gracefully")
  httpServer.close(() => {
    logger.info("HTTP server closed")
    process.exit(0)
  })
})
