import amqplib, { type Channel, type Connection } from "amqplib"
import { logger } from "../utils/logger"

// RabbitMQ connection variables
let connection: Connection | null = null
let channel: Channel | null = null

// Queue names
export const QUEUE_MESSAGES = "wa_messages"
export const QUEUE_CHECKS = "wa_checks"

// Connect to RabbitMQ
export async function connect(): Promise<void> {
  try {
    const rabbitmqUrl = process.env.RABBITMQ_URL || "amqp://localhost"
    connection = await amqplib.connect(rabbitmqUrl)

    // Create channel
    channel = await connection.createChannel()

    // Ensure queues exist
    await channel.assertQueue(QUEUE_MESSAGES, { durable: true })
    await channel.assertQueue(QUEUE_CHECKS, { durable: true })

    // Handle connection close
    connection.on("close", () => {
      logger.warn("RabbitMQ connection closed, attempting to reconnect...")
      setTimeout(connect, 5000)
    })

    logger.info("Connected to RabbitMQ")
  } catch (error) {
    logger.error("Failed to connect to RabbitMQ:", error)
    setTimeout(connect, 5000)
  }
}

// Send message to queue
export async function sendToQueue(queue: string, message: any): Promise<boolean> {
  try {
    if (!channel) {
      throw new Error("RabbitMQ channel not available")
    }

    const success = channel.sendToQueue(queue, Buffer.from(JSON.stringify(message)), { persistent: true })

    return success
  } catch (error) {
    logger.error(`Error sending message to queue ${queue}:`, error)
    return false
  }
}

// Consume messages from queue
export async function consumeFromQueue(queue: string, callback: (message: any) => Promise<void>): Promise<void> {
  try {
    if (!channel) {
      throw new Error("RabbitMQ channel not available")
    }

    await channel.prefetch(1)

    await channel.consume(queue, async (msg) => {
      if (msg) {
        try {
          const content = JSON.parse(msg.content.toString())
          await callback(content)
          channel?.ack(msg)
        } catch (error) {
          logger.error(`Error processing message from queue ${queue}:`, error)
          // Requeue the message after a delay
          setTimeout(() => {
            channel?.nack(msg, false, true)
          }, 5000)
        }
      }
    })

    logger.info(`Consumer registered for queue: ${queue}`)
  } catch (error) {
    logger.error(`Error consuming from queue ${queue}:`, error)
    throw error
  }
}

// Close connection
export async function close(): Promise<void> {
  try {
    if (channel) {
      await channel.close()
    }
    if (connection) {
      await connection.close()
    }
    logger.info("RabbitMQ connection closed")
  } catch (error) {
    logger.error("Error closing RabbitMQ connection:", error)
  }
}
