import { consumeFromQueue, QUEUE_MESSAGES, QUEUE_CHECKS } from "./rabbitmq"
import { checkWhatsappNumber, sendWhatsappMessage } from "./greenapi"
import { supabase } from "./database"
import { logger } from "../utils/logger"
import type { Server } from "socket.io"
import { randomDelay } from "../utils/helpers"

// Setup worker
export async function setupWorker(): Promise<void> {
  try {
    // Process WhatsApp number checks
    await consumeFromQueue(QUEUE_CHECKS, async (message) => {
      const { contactId, instanceId, token } = message

      logger.info(`Checking WhatsApp for contact ${contactId}`)

      try {
        // Get contact details
        const { data: contact, error: contactError } = await supabase
          .from("contacts")
          .select("phone")
          .eq("id", contactId)
          .single()

        if (contactError || !contact) {
          throw new Error(`Contact not found: ${contactError?.message}`)
        }

        // Check if number has WhatsApp
        const hasWhatsapp = await checkWhatsappNumber(instanceId, token, contact.phone)

        // Update contact in database
        const { error: updateError } = await supabase
          .from("contacts")
          .update({
            hasWhatsapp,
            lastChecked: new Date().toISOString(),
          })
          .eq("id", contactId)

        if (updateError) {
          throw new Error(`Failed to update contact: ${updateError.message}`)
        }

        // Emit log via Socket.IO if available
        const io = global.io as Server | undefined
        if (io) {
          io.emit("log", {
            type: hasWhatsapp ? "success" : "info",
            message: `Контакт ${contact.phone} ${hasWhatsapp ? "имеет" : "не имеет"} WhatsApp`,
            timestamp: new Date(),
          })
        }

        logger.info(`Contact ${contact.phone} WhatsApp status: ${hasWhatsapp}`)
      } catch (error) {
        logger.error(`Error checking WhatsApp for contact ${contactId}:`, error)

        // Emit error log via Socket.IO if available
        const io = global.io as Server | undefined
        if (io) {
          io.emit("log", {
            type: "error",
            message: `Ошибка проверки WhatsApp: ${(error as Error).message}`,
            timestamp: new Date(),
          })
        }
      }
    })

    // Process WhatsApp messages
    await consumeFromQueue(QUEUE_MESSAGES, async (message) => {
      const { messageId, campaignId, contactId, instanceId, token, text, useRandomization } = message

      logger.info(`Processing message ${messageId} for campaign ${campaignId}`)

      try {
        // Get contact details
        const { data: contact, error: contactError } = await supabase
          .from("contacts")
          .select("phone, name")
          .eq("id", contactId)
          .single()

        if (contactError || !contact) {
          throw new Error(`Contact not found: ${contactError?.message}`)
        }

        // Apply randomization if needed
        let finalText = text
        if (useRandomization) {
          finalText = applyRandomization(text)
        }

        // Replace variables in text
        finalText = finalText.replace(/{имя}/g, contact.name || "")

        // Add random delay to avoid spam detection
        const { data: settings } = await supabase.from("settings").select("messageDelay").single()

        const minDelay = settings?.messageDelay?.min || 1000
        const maxDelay = settings?.messageDelay?.max || 3000

        await randomDelay(minDelay, maxDelay)

        // Send message
        const result = await sendWhatsappMessage(instanceId, token, contact.phone, finalText)

        // Update message log
        const { error: updateError } = await supabase
          .from("message_logs")
          .update({
            status: result.success ? "delivered" : "failed",
            deliveredAt: result.success ? new Date().toISOString() : null,
            error: result.error || null,
          })
          .eq("id", messageId)

        if (updateError) {
          throw new Error(`Failed to update message log: ${updateError.message}`)
        }

        // Update campaign stats
        await supabase.rpc("update_campaign_stats", {
          p_campaign_id: campaignId,
          p_delivered: result.success ? 1 : 0,
          p_failed: result.success ? 0 : 1,
        })

        // Emit log via Socket.IO if available
        const io = global.io as Server | undefined
        if (io) {
          io.emit("log", {
            type: result.success ? "success" : "error",
            message: result.success
              ? `Сообщение отправлено на ${contact.phone}`
              : `Ошибка отправки на ${contact.phone}: ${result.error}`,
            timestamp: new Date(),
          })
        }

        logger.info(`Message ${messageId} sent to ${contact.phone}: ${result.success ? "success" : "failed"}`)
      } catch (error) {
        logger.error(`Error sending message ${messageId}:`, error)

        // Update message log with error
        await supabase
          .from("message_logs")
          .update({
            status: "failed",
            error: (error as Error).message,
          })
          .eq("id", messageId)

        // Emit error log via Socket.IO if available
        const io = global.io as Server | undefined
        if (io) {
          io.emit("log", {
            type: "error",
            message: `Ошибка отправки: ${(error as Error).message}`,
            timestamp: new Date(),
          })
        }
      }
    })

    logger.info("Worker service initialized successfully")
  } catch (error) {
    logger.error("Failed to setup worker:", error)
    throw error
  }
}

// Apply randomization to text
function applyRandomization(text: string): string {
  // Simple randomization for demonstration
  // In a real app, this would be more sophisticated

  // Replace common phrases with alternatives
  const greetings = ["Здравствуйте", "Добрый день", "Приветствую"]
  const thanks = ["Спасибо", "Благодарю", "Признателен"]
  const regards = ["С уважением", "С наилучшими пожеланиями", "Всего доброго"]

  let result = text
    .replace(/Здравствуйте/g, () => greetings[Math.floor(Math.random() * greetings.length)])
    .replace(/Спасибо/g, () => thanks[Math.floor(Math.random() * thanks.length)])
    .replace(/С уважением/g, () => regards[Math.floor(Math.random() * regards.length)])

  // Add random spaces or invisible characters
  result = result.replace(/ /g, () => (Math.random() > 0.8 ? " " : " "))

  return result
}
