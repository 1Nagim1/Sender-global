import { createClient } from "@supabase/supabase-js"
import { logger } from "../utils/logger"
import type { Database } from "../types/database"

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL || ""
const supabaseKey = process.env.SUPABASE_KEY || ""

if (!supabaseUrl || !supabaseKey) {
  logger.error("Missing Supabase credentials")
  process.exit(1)
}

export const supabase = createClient<Database>(supabaseUrl, supabaseKey)

// Setup database function
export async function setupDatabase() {
  try {
    // Check connection
    const { data, error } = await supabase.from("instances").select("count")

    if (error) {
      throw new Error(`Database connection error: ${error.message}`)
    }

    logger.info("Database connection successful")
    return true
  } catch (error) {
    logger.error("Database setup failed:", error)
    throw error
  }
}

// Helper function to create tables if they don't exist
export async function ensureTablesExist() {
  try {
    // This would typically be handled by migrations
    // For simplicity, we're checking if tables exist and creating them if needed

    // Check if instances table exists
    const { error: instancesError } = await supabase.from("instances").select("id").limit(1)

    if (instancesError && instancesError.code === "42P01") {
      // Table doesn't exist, create it
      await supabase.rpc("create_instances_table")
    }

    // Check if messages table exists
    const { error: messagesError } = await supabase.from("message_templates").select("id").limit(1)

    if (messagesError && messagesError.code === "42P01") {
      // Table doesn't exist, create it
      await supabase.rpc("create_message_templates_table")
    }

    // Check if contacts table exists
    const { error: contactsError } = await supabase.from("contacts").select("id").limit(1)

    if (contactsError && contactsError.code === "42P01") {
      // Table doesn't exist, create it
      await supabase.rpc("create_contacts_table")
    }

    // Check if campaigns table exists
    const { error: campaignsError } = await supabase.from("campaigns").select("id").limit(1)

    if (campaignsError && campaignsError.code === "42P01") {
      // Table doesn't exist, create it
      await supabase.rpc("create_campaigns_table")
    }

    // Check if message_logs table exists
    const { error: logsError } = await supabase.from("message_logs").select("id").limit(1)

    if (logsError && logsError.code === "42P01") {
      // Table doesn't exist, create it
      await supabase.rpc("create_message_logs_table")
    }

    // Check if settings table exists
    const { error: settingsError } = await supabase.from("settings").select("id").limit(1)

    if (settingsError && settingsError.code === "42P01") {
      // Table doesn't exist, create it
      await supabase.rpc("create_settings_table")
    }

    logger.info("Database tables verified")
    return true
  } catch (error) {
    logger.error("Error ensuring tables exist:", error)
    throw error
  }
}
