import axios from "axios"
import { logger } from "../utils/logger"

// Base URL for Green API
const BASE_URL = "https://api.green-api.com"

// Check if a phone number has WhatsApp
export async function checkWhatsappNumber(instanceId: string, token: string, phone: string): Promise<boolean> {
  try {
    const url = `${BASE_URL}/waInstance${instanceId}/checkWhatsapp/${token}`
    const response = await axios.post(url, { phoneNumber: phone })

    if (response.status === 200 && response.data) {
      return response.data.existsWhatsapp === true
    }

    return false
  } catch (error) {
    logger.error(`Error checking WhatsApp for ${phone}:`, error)
    return false
  }
}

// Send WhatsApp message
export async function sendWhatsappMessage(
  instanceId: string,
  token: string,
  phone: string,
  message: string,
): Promise<{ success: boolean; error?: string }> {
  try {
    const url = `${BASE_URL}/waInstance${instanceId}/sendMessage/${token}`
    const response = await axios.post(url, {
      chatId: `${phone}@c.us`,
      message,
    })

    if (response.status === 200 && response.data && response.data.idMessage) {
      return { success: true }
    }

    return {
      success: false,
      error: response.data?.description || "Unknown error",
    }
  } catch (error) {
    const errorMessage = axios.isAxiosError(error)
      ? error.response?.data?.description || error.message
      : (error as Error).message

    logger.error(`Error sending WhatsApp message to ${phone}:`, error)
    return { success: false, error: errorMessage }
  }
}

// Get instance status
export async function getInstanceStatus(
  instanceId: string,
  token: string,
): Promise<{ active: boolean; error?: string }> {
  try {
    const url = `${BASE_URL}/waInstance${instanceId}/getStateInstance/${token}`
    const response = await axios.get(url)

    if (response.status === 200 && response.data) {
      const stateInstance = response.data.stateInstance
      return { active: stateInstance === "authorized" }
    }

    return {
      active: false,
      error: response.data?.description || "Unknown error",
    }
  } catch (error) {
    const errorMessage = axios.isAxiosError(error)
      ? error.response?.data?.description || error.message
      : (error as Error).message

    logger.error(`Error getting instance status for ${instanceId}:`, error)
    return { active: false, error: errorMessage }
  }
}
