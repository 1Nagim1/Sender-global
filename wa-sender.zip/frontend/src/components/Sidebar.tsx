"use client"

import { useState, useEffect } from "react"
import { Link, useLocation } from "react-router-dom"
import { BarChart3, MessageSquare, Users, Settings, Menu, X, Home, Send, KeyRound } from "lucide-react"
import { Button } from "./ui/button"
import { useTheme } from "./theme-provider"
import { cn } from "../lib/utils"

interface SidebarProps {
  isMobileMenuOpen: boolean
  setIsMobileMenuOpen: (open: boolean) => void
}

const Sidebar = ({ isMobileMenuOpen, setIsMobileMenuOpen }: SidebarProps) => {
  const location = useLocation()
  const { theme, setTheme } = useTheme()
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  const toggleTheme = () => {
    if (isMounted) {
      setTheme(theme === "dark" ? "light" : "dark")
    }
  }

  const navigation = [
    { name: "Дашборд", href: "/", icon: Home },
    { name: "Инстансы", href: "/instances", icon: KeyRound },
    { name: "Сообщения", href: "/messages", icon: MessageSquare },
    { name: "Контакты", href: "/contacts", icon: Users },
    { name: "Кампании", href: "/campaigns", icon: Send },
    { name: "Аналитика", href: "/analytics", icon: BarChart3 },
    { name: "Настройки", href: "/settings", icon: Settings },
  ]

  return (
    <>
      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="icon"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Sidebar for mobile */}
      <div
        className={cn(
          "fixed inset-0 z-40 lg:hidden transform transition-transform duration-300 ease-in-out",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="relative flex flex-col h-full max-w-xs w-full bg-background border-r pt-16 pb-4 px-2">
          <div className="flex items-center justify-center mb-8">
            <h1 className="text-2xl font-bold text-primary">WA-Sender</h1>
          </div>
          <nav className="flex-1 space-y-1 px-2">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={cn(
                  "flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors",
                  location.pathname === item.href
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted",
                )}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <item.icon className="mr-3 h-5 w-5" />
                {item.name}
              </Link>
            ))}
          </nav>
          <div className="px-4 mt-auto">
            <Button variant="outline" size="sm" className="w-full justify-start" onClick={toggleTheme}>
              {theme === "dark" ? "☀️ Светлая тема" : "🌙 Темная тема"}
            </Button>
          </div>
        </div>
      </div>

      {/* Sidebar for desktop */}
      <div className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 border-r">
        <div className="flex flex-col h-full py-4 px-2">
          <div className="flex items-center justify-center mb-8 px-4">
            <h1 className="text-2xl font-bold text-primary">WA-Sender</h1>
          </div>
          <nav className="flex-1 space-y-1 px-2">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={cn(
                  "flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors",
                  location.pathname === item.href
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted",
                )}
              >
                <item.icon className="mr-3 h-5 w-5" />
                {item.name}
              </Link>
            ))}
          </nav>
          <div className="px-4 mt-auto">
            <Button variant="outline" size="sm" className="w-full justify-start" onClick={toggleTheme}>
              {theme === "dark" ? "☀️ Светлая тема" : "🌙 Темная тема"}
            </Button>
          </div>
        </div>
      </div>
    </>
  )
}

export default Sidebar
