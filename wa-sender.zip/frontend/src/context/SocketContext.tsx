"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { io, type Socket } from "socket.io-client"
import { useToast } from "../hooks/use-toast"

interface SocketContextType {
  socket: Socket | null
  connected: boolean
  logs: LogMessage[]
}

interface LogMessage {
  id: string
  type: "info" | "success" | "error" | "warning"
  message: string
  timestamp: Date
}

const SocketContext = createContext<SocketContextType>({
  socket: null,
  connected: false,
  logs: [],
})

export const useSocket = () => useContext(SocketContext)

export const SocketProvider = ({ children }: { children: ReactNode }) => {
  const [socket, setSocket] = useState<Socket | null>(null)
  const [connected, setConnected] = useState(false)
  const [logs, setLogs] = useState<LogMessage[]>([])
  const { toast } = useToast()

  useEffect(() => {
    const socketInstance = io(import.meta.env.VITE_API_URL, {
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    })

    socketInstance.on("connect", () => {
      setConnected(true)
      toast({
        title: "WebSocket подключен",
        description: "Соединение с сервером установлено",
      })
    })

    socketInstance.on("disconnect", () => {
      setConnected(false)
      toast({
        title: "WebSocket отключен",
        description: "Соединение с сервером потеряно",
        variant: "destructive",
      })
    })

    socketInstance.on("log", (logMessage: Omit<LogMessage, "id">) => {
      setLogs((prev) => [
        {
          ...logMessage,
          id: crypto.randomUUID(),
          timestamp: new Date(logMessage.timestamp),
        },
        ...prev.slice(0, 99), // Keep only the last 100 logs
      ])
    })

    setSocket(socketInstance)

    return () => {
      socketInstance.disconnect()
    }
  }, [toast])

  return <SocketContext.Provider value={{ socket, connected, logs }}>{children}</SocketContext.Provider>
}
