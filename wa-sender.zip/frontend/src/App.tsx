"use client"

import { useState, useEffect } from "react"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { ThemeProvider } from "./components/theme-provider"
import Sidebar from "./components/Sidebar"
import Dashboard from "./pages/Dashboard"
import Instances from "./pages/Instances"
import Messages from "./pages/Messages"
import Contacts from "./pages/Contacts"
import Campaigns from "./pages/Campaigns"
import Analytics from "./pages/Analytics"
import Settings from "./pages/Settings"
import { Toaster } from "./components/ui/toaster"
import { useToast } from "./hooks/use-toast"
import { SocketProvider } from "./context/SocketContext"

function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    // Check if the app is installed on the server
    const checkServerStatus = async () => {
      try {
        const response = await fetch(`${import.meta.env.VITE_API_URL}/api/status`)
        if (response.ok) {
          toast({
            title: "Сервер подключен",
            description: "Соединение с сервером установлено успешно",
          })
        } else {
          toast({
            title: "Ошибка соединения",
            description: "Не удалось подключиться к серверу",
            variant: "destructive",
          })
        }
      } catch (error) {
        toast({
          title: "Ошибка соединения",
          description: "Не удалось подключиться к серверу",
          variant: "destructive",
        })
      }
    }

    checkServerStatus()
  }, [toast])

  return (
    <ThemeProvider defaultTheme="dark" storageKey="wa-sender-theme">
      <SocketProvider>
        <Router>
          <div className="flex h-screen overflow-hidden bg-background">
            <Sidebar isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} />
            <div className="flex flex-col flex-1 overflow-hidden">
              <main className="flex-1 overflow-y-auto p-4 md:p-6">
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/instances" element={<Instances />} />
                  <Route path="/messages" element={<Messages />} />
                  <Route path="/contacts" element={<Contacts />} />
                  <Route path="/campaigns" element={<Campaigns />} />
                  <Route path="/analytics" element={<Analytics />} />
                  <Route path="/settings" element={<Settings />} />
                </Routes>
              </main>
            </div>
          </div>
          <Toaster />
        </Router>
      </SocketProvider>
    </ThemeProvider>
  )
}

export default App
