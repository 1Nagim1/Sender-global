"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { Input } from "../components/ui/input"
import { Label } from "../components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "../components/ui/alert-dialog"
import { useToast } from "../hooks/use-toast"
import { Loader2, Plus, Trash2, Upload, Download, CheckCircle2, XCircle } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs"
import { Textarea } from "../components/ui/textarea"
import { Badge } from "../components/ui/badge"
import { ScrollArea } from "../components/ui/scroll-area"

interface Contact {
  id: string
  phone: string
  name: string
  hasWhatsapp: boolean | null
  lastChecked: string | null
  createdAt: string
}

const Contacts = () => {
  const [contacts, setContacts] = useState<Contact[]>([])
  const [loading, setLoading] = useState(true)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false)
  const [newContact, setNewContact] = useState({
    phone: "",
    name: "",
  })
  const [bulkContacts, setBulkContacts] = useState("")
  const [importResults, setImportResults] = useState<{
    total: number
    success: number
    failed: number
    errors: string[]
  } | null>(null)
  const [checkingContact, setCheckingContact] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const fetchContacts = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/contacts`)
      if (response.ok) {
        const data = await response.json()
        setContacts(data)
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить контакты",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить контакты",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchContacts()
  }, [toast])

  const handleAddContact = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/contacts`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newContact),
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Контакт добавлен",
        })
        setIsAddDialogOpen(false)
        setNewContact({ phone: "", name: "" })
        fetchContacts()
      } else {
        const error = await response.json()
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось добавить контакт",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось добавить контакт",
        variant: "destructive",
      })
    }
  }

  const handleDeleteContact = async (id: string) => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/contacts/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Контакт удален",
        })
        fetchContacts()
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось удалить контакт",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить контакт",
        variant: "destructive",
      })
    }
  }

  const handleCheckWhatsapp = async (id: string) => {
    setCheckingContact(id)
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/contacts/${id}/check`, {
        method: "POST",
      })

      if (response.ok) {
        toast({
          title: "Проверка завершена",
          description: "Статус WhatsApp обновлен",
        })
        fetchContacts()
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось проверить номер",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось проверить номер",
        variant: "destructive",
      })
    } finally {
      setCheckingContact(null)
    }
  }

  const handleBulkImport = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/contacts/bulk`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ contacts: bulkContacts }),
      })

      const result = await response.json()

      if (response.ok) {
        setImportResults(result)
        if (result.success > 0) {
          toast({
            title: "Импорт завершен",
            description: `Успешно импортировано ${result.success} из ${result.total} контактов`,
          })
          fetchContacts()
        } else {
          toast({
            title: "Импорт завершен с ошибками",
            description: `Не удалось импортировать контакты`,
            variant: "destructive",
          })
        }
      } else {
        toast({
          title: "Ошибка",
          description: result.message || "Не удалось импортировать контакты",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось импортировать контакты",
        variant: "destructive",
      })
    }
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      const content = e.target?.result as string
      setBulkContacts(content)
    }
    reader.readAsText(file)
  }

  const handleExportContacts = () => {
    // Create CSV content
    const csvContent = ["phone,name", ...contacts.map((contact) => `${contact.phone},${contact.name}`)].join("\n")

    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `contacts-${new Date().toISOString().split("T")[0]}.csv`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const getWhatsappStatus = (contact: Contact) => {
    if (contact.hasWhatsapp === null) {
      return <Badge variant="outline">Не проверен</Badge>
    } else if (contact.hasWhatsapp) {
      return <Badge className="bg-green-500">Есть WhatsApp</Badge>
    } else {
      return <Badge variant="secondary">Нет WhatsApp</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Контакты</h1>
        <div className="flex gap-2">
          <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Upload className="mr-2 h-4 w-4" />
                Импорт
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Импорт контактов</DialogTitle>
                <DialogDescription>Импортируйте контакты из CSV файла или вставьте список номеров</DialogDescription>
              </DialogHeader>
              <Tabs defaultValue="paste">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="paste">Вставить текст</TabsTrigger>
                  <TabsTrigger value="file">Загрузить файл</TabsTrigger>
                </TabsList>
                <TabsContent value="paste" className="space-y-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="bulk-contacts">Список контактов</Label>
                    <Textarea
                      id="bulk-contacts"
                      placeholder="79001234567,Иван Иванов
79001234568,Петр Петров"
                      rows={10}
                      value={bulkContacts}
                      onChange={(e) => setBulkContacts(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">Формат: телефон,имя (по одному на строку)</p>
                  </div>
                </TabsContent>
                <TabsContent value="file" className="space-y-4 py-4">
                  <div className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="csv-file">CSV файл</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="csv-file"
                          type="file"
                          accept=".csv,.txt"
                          ref={fileInputRef}
                          onChange={handleFileUpload}
                          className="flex-1"
                        />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Поддерживаются файлы CSV с колонками "phone" и "name"
                      </p>
                    </div>
                    {bulkContacts && (
                      <div className="grid gap-2">
                        <Label>Предпросмотр</Label>
                        <ScrollArea className="h-[200px] w-full rounded-md border p-4">
                          <pre className="text-xs">{bulkContacts}</pre>
                        </ScrollArea>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
              {importResults && (
                <div className="mt-4 p-4 border rounded-md bg-muted">
                  <h4 className="font-medium mb-2">Результаты импорта</h4>
                  <div className="grid grid-cols-3 gap-2 mb-2">
                    <div className="text-center">
                      <div className="text-lg font-bold">{importResults.total}</div>
                      <div className="text-xs text-muted-foreground">Всего</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-green-500">{importResults.success}</div>
                      <div className="text-xs text-muted-foreground">Успешно</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-red-500">{importResults.failed}</div>
                      <div className="text-xs text-muted-foreground">Ошибки</div>
                    </div>
                  </div>
                  {importResults.errors.length > 0 && (
                    <ScrollArea className="h-[100px] w-full rounded-md border p-2">
                      <ul className="text-xs space-y-1">
                        {importResults.errors.map((error, index) => (
                          <li key={index} className="text-red-500">
                            {error}
                          </li>
                        ))}
                      </ul>
                    </ScrollArea>
                  )}
                </div>
              )}
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsImportDialogOpen(false)
                    setBulkContacts("")
                    setImportResults(null)
                    if (fileInputRef.current) fileInputRef.current.value = ""
                  }}
                >
                  Отмена
                </Button>
                <Button onClick={handleBulkImport} disabled={!bulkContacts.trim()}>
                  Импортировать
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          <Button variant="outline" onClick={handleExportContacts} disabled={contacts.length === 0}>
            <Download className="mr-2 h-4 w-4" />
            Экспорт
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Добавить контакт
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Добавить новый контакт</DialogTitle>
                <DialogDescription>Добавьте новый контакт для рассылки WhatsApp сообщений</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="phone">Номер телефона</Label>
                  <Input
                    id="phone"
                    placeholder="79001234567"
                    value={newContact.phone}
                    onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                  />
                  <p className="text-xs text-muted-foreground">Формат: 79XXXXXXXXX (без + и других символов)</p>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="name">Имя (опционально)</Label>
                  <Input
                    id="name"
                    placeholder="Иван Иванов"
                    value={newContact.name}
                    onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Отмена
                </Button>
                <Button onClick={handleAddContact}>Добавить</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Управление контактами</CardTitle>
          <CardDescription>Управляйте списком контактов для рассылки WhatsApp сообщений</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : contacts.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Телефон</TableHead>
                  <TableHead>Имя</TableHead>
                  <TableHead>WhatsApp</TableHead>
                  <TableHead>Последняя проверка</TableHead>
                  <TableHead>Дата добавления</TableHead>
                  <TableHead className="text-right">Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {contacts.map((contact) => (
                  <TableRow key={contact.id}>
                    <TableCell className="font-medium">{contact.phone}</TableCell>
                    <TableCell>{contact.name || "-"}</TableCell>
                    <TableCell>{getWhatsappStatus(contact)}</TableCell>
                    <TableCell>
                      {contact.lastChecked ? new Date(contact.lastChecked).toLocaleString() : "Не проверялся"}
                    </TableCell>
                    <TableCell>{new Date(contact.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleCheckWhatsapp(contact.id)}
                          disabled={checkingContact === contact.id}
                        >
                          {checkingContact === contact.id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : contact.hasWhatsapp ? (
                            <CheckCircle2 className="h-4 w-4 text-green-500" />
                          ) : (
                            <XCircle className="h-4 w-4" />
                          )}
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Вы уверены?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Это действие нельзя отменить. Контакт будет удален из системы.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Отмена</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteContact(contact.id)}>
                                Удалить
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center h-40 text-center">
              <p className="text-muted-foreground mb-4">Нет добавленных контактов</p>
              <Button onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Добавить первый контакт
              </Button>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <p className="text-sm text-muted-foreground">Всего контактов: {contacts.length}</p>
        </CardFooter>
      </Card>
    </div>
  )
}

export default Contacts
