"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { Input } from "../components/ui/input"
import { Label } from "../components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "../components/ui/alert-dialog"
import { Badge } from "../components/ui/badge"
import { useToast } from "../hooks/use-toast"
import { Loader2, Plus, Trash2, RefreshCw } from "lucide-react"

interface Instance {
  id: string
  instanceId: string
  token: string
  name: string
  status: "active" | "inactive" | "error"
  messagesCount: number
  createdAt: string
}

const Instances = () => {
  const [instances, setInstances] = useState<Instance[]>([])
  const [loading, setLoading] = useState(true)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newInstance, setNewInstance] = useState({
    instanceId: "",
    token: "",
    name: "",
  })
  const [checkingInstance, setCheckingInstance] = useState<string | null>(null)
  const { toast } = useToast()

  const fetchInstances = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/instances`)
      if (response.ok) {
        const data = await response.json()
        setInstances(data)
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить инстансы",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить инстансы",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchInstances()
  }, [toast])

  const handleAddInstance = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/instances`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newInstance),
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Инстанс добавлен",
        })
        setIsAddDialogOpen(false)
        setNewInstance({ instanceId: "", token: "", name: "" })
        fetchInstances()
      } else {
        const error = await response.json()
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось добавить инстанс",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось добавить инстанс",
        variant: "destructive",
      })
    }
  }

  const handleDeleteInstance = async (id: string) => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/instances/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Инстанс удален",
        })
        fetchInstances()
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось удалить инстанс",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить инстанс",
        variant: "destructive",
      })
    }
  }

  const checkInstanceStatus = async (id: string) => {
    setCheckingInstance(id)
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/instances/${id}/check`, {
        method: "POST",
      })

      if (response.ok) {
        toast({
          title: "Проверка завершена",
          description: "Статус инстанса обновлен",
        })
        fetchInstances()
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось проверить инстанс",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось проверить инстанс",
        variant: "destructive",
      })
    } finally {
      setCheckingInstance(null)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Активен</Badge>
      case "inactive":
        return <Badge variant="outline">Неактивен</Badge>
      case "error":
        return <Badge variant="destructive">Ошибка</Badge>
      default:
        return <Badge variant="secondary">Неизвестно</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Инстансы Green API</h1>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Добавить инстанс
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Добавить новый инстанс</DialogTitle>
              <DialogDescription>Добавьте данные инстанса Green API для отправки сообщений.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Название</Label>
                <Input
                  id="name"
                  placeholder="Мой инстанс"
                  value={newInstance.name}
                  onChange={(e) => setNewInstance({ ...newInstance, name: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="instanceId">ID инстанса</Label>
                <Input
                  id="instanceId"
                  placeholder="1101000000"
                  value={newInstance.instanceId}
                  onChange={(e) => setNewInstance({ ...newInstance, instanceId: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="token">API токен</Label>
                <Input
                  id="token"
                  type="password"
                  placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                  value={newInstance.token}
                  onChange={(e) => setNewInstance({ ...newInstance, token: e.target.value })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Отмена
              </Button>
              <Button onClick={handleAddInstance}>Добавить</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Управление инстансами</CardTitle>
          <CardDescription>Управляйте инстансами Green API для отправки сообщений WhatsApp</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : instances.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Название</TableHead>
                  <TableHead>ID инстанса</TableHead>
                  <TableHead>Статус</TableHead>
                  <TableHead>Сообщений</TableHead>
                  <TableHead>Дата добавления</TableHead>
                  <TableHead className="text-right">Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {instances.map((instance) => (
                  <TableRow key={instance.id}>
                    <TableCell className="font-medium">{instance.name}</TableCell>
                    <TableCell>{instance.instanceId}</TableCell>
                    <TableCell>{getStatusBadge(instance.status)}</TableCell>
                    <TableCell>{instance.messagesCount}</TableCell>
                    <TableCell>{new Date(instance.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => checkInstanceStatus(instance.id)}
                          disabled={checkingInstance === instance.id}
                        >
                          {checkingInstance === instance.id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <RefreshCw className="h-4 w-4" />
                          )}
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Вы уверены?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Это действие нельзя отменить. Инстанс будет удален из системы.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Отмена</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteInstance(instance.id)}>
                                Удалить
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center h-40 text-center">
              <p className="text-muted-foreground mb-4">Нет добавленных инстансов</p>
              <Button onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Добавить первый инстанс
              </Button>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <p className="text-sm text-muted-foreground">Всего инстансов: {instances.length}</p>
          <Button variant="outline" size="sm" onClick={fetchInstances}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Обновить
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

export default Instances
