"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card"
import { Progress } from "../components/ui/progress"
import { useSocket } from "../context/SocketContext"
import { ScrollArea } from "../components/ui/scroll-area"
import { Badge } from "../components/ui/badge"
import { CheckCircle, AlertCircle, Info, AlertTriangle } from "lucide-react"
import { cn } from "../lib/utils"

interface Stats {
  totalInstances: number
  activeInstances: number
  totalMessages: number
  deliveredMessages: number
  pendingMessages: number
  failedMessages: number
}

const Dashboard = () => {
  const { connected, logs } = useSocket()
  const [stats, setStats] = useState<Stats>({
    totalInstances: 0,
    activeInstances: 0,
    totalMessages: 0,
    deliveredMessages: 0,
    pendingMessages: 0,
    failedMessages: 0,
  })

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch(`${import.meta.env.VITE_API_URL}/api/stats`)
        if (response.ok) {
          const data = await response.json()
          setStats(data)
        }
      } catch (error) {
        console.error("Failed to fetch stats:", error)
      }
    }

    fetchStats()
    const interval = setInterval(fetchStats, 30000) // Update every 30 seconds

    return () => clearInterval(interval)
  }, [])

  const getLogIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "error":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      default:
        return <Info className="h-4 w-4 text-blue-500" />
    }
  }

  const deliveryRate = stats.totalMessages > 0 ? Math.round((stats.deliveredMessages / stats.totalMessages) * 100) : 0

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Дашборд</h1>
        <Badge variant={connected ? "default" : "destructive"}>{connected ? "Онлайн" : "Офлайн"}</Badge>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Инстансы</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.activeInstances}/{stats.totalInstances}
            </div>
            <p className="text-xs text-muted-foreground">Активных инстансов</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Всего сообщений</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalMessages}</div>
            <p className="text-xs text-muted-foreground">За все время</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Доставлено</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.deliveredMessages}</div>
            <p className="text-xs text-muted-foreground">Успешно доставлено</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Не доставлено</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.failedMessages}</div>
            <p className="text-xs text-muted-foreground">Ошибки доставки</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Статистика доставки</CardTitle>
          <CardDescription>Процент успешно доставленных сообщений</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <div>Доставлено</div>
              <div className="font-medium">{deliveryRate}%</div>
            </div>
            <Progress value={deliveryRate} className="h-2" />
          </div>
        </CardContent>
      </Card>

      <Card className="col-span-full">
        <CardHeader>
          <CardTitle>Логи системы</CardTitle>
          <CardDescription>Последние события в реальном времени</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px] w-full rounded-md border p-4">
            {logs.length > 0 ? (
              <div className="space-y-3">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className={cn(
                      "flex items-start gap-2 text-sm border-l-2 pl-3",
                      log.type === "success" && "border-green-500",
                      log.type === "error" && "border-red-500",
                      log.type === "warning" && "border-yellow-500",
                      log.type === "info" && "border-blue-500",
                    )}
                  >
                    <div className="mt-0.5">{getLogIcon(log.type)}</div>
                    <div className="flex-1">
                      <p>{log.message}</p>
                      <p className="text-xs text-muted-foreground">{log.timestamp.toLocaleTimeString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex h-full items-center justify-center text-muted-foreground">Нет доступных логов</div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  )
}

export default Dashboard
