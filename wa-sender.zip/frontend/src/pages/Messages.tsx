"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { Input } from "../components/ui/input"
import { Label } from "../components/ui/label"
import { Textarea } from "../components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "../components/ui/alert-dialog"
import { useToast } from "../hooks/use-toast"
import { Loader2, Plus, Trash2, Pencil, Wand2 } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs"

interface MessageTemplate {
  id: string
  name: string
  content: string
  variables: string[]
  createdAt: string
}

const Messages = () => {
  const [templates, setTemplates] = useState<MessageTemplate[]>([])
  const [loading, setLoading] = useState(true)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [currentTemplate, setCurrentTemplate] = useState<MessageTemplate | null>(null)
  const [newTemplate, setNewTemplate] = useState({
    name: "",
    content: "",
  })
  const [randomizedContent, setRandomizedContent] = useState("")
  const { toast } = useToast()

  const fetchTemplates = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/messages`)
      if (response.ok) {
        const data = await response.json()
        setTemplates(data)
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить шаблоны сообщений",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить шаблоны сообщений",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchTemplates()
  }, [toast])

  const handleAddTemplate = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/messages`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newTemplate),
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Шаблон сообщения добавлен",
        })
        setIsAddDialogOpen(false)
        setNewTemplate({ name: "", content: "" })
        fetchTemplates()
      } else {
        const error = await response.json()
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось добавить шаблон",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось добавить шаблон",
        variant: "destructive",
      })
    }
  }

  const handleEditTemplate = async () => {
    if (!currentTemplate) return

    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/messages/${currentTemplate.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: currentTemplate.name,
          content: currentTemplate.content,
        }),
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Шаблон сообщения обновлен",
        })
        setIsEditDialogOpen(false)
        fetchTemplates()
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось обновить шаблон",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить шаблон",
        variant: "destructive",
      })
    }
  }

  const handleDeleteTemplate = async (id: string) => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/messages/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Шаблон сообщения удален",
        })
        fetchTemplates()
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось удалить шаблон",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить шаблон",
        variant: "destructive",
      })
    }
  }

  const generateRandomizedContent = () => {
    if (!currentTemplate) return

    // Simple randomization logic for demonstration
    const content = currentTemplate.content

    // Replace common phrases with alternatives
    const randomized = content
      .replace(/Здравствуйте/g, ["Здравствуйте", "Добрый день", "Приветствую"][Math.floor(Math.random() * 3)])
      .replace(/Спасибо/g, ["Спасибо", "Благодарю", "Признателен"][Math.floor(Math.random() * 3)])
      .replace(/Пожалуйста/g, ["Пожалуйста", "Будьте добры", "Прошу вас"][Math.floor(Math.random() * 3)])

    setRandomizedContent(randomized)
  }

  const extractVariables = (content: string) => {
    const regex = /\{([^}]+)\}/g
    const variables = []
    let match

    while ((match = regex.exec(content)) !== null) {
      variables.push(match[1])
    }

    return variables
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Шаблоны сообщений</h1>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Создать шаблон
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Создать шаблон сообщения</DialogTitle>
              <DialogDescription>
                Создайте новый шаблон для массовой рассылки. Используйте {"{переменная}"} для динамического контента.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Название шаблона</Label>
                <Input
                  id="name"
                  placeholder="Приветственное сообщение"
                  value={newTemplate.name}
                  onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="content">Текст сообщения</Label>
                <Textarea
                  id="content"
                  placeholder="Здравствуйте, {имя}! Благодарим за интерес к нашим услугам."
                  rows={6}
                  value={newTemplate.content}
                  onChange={(e) => setNewTemplate({ ...newTemplate, content: e.target.value })}
                />
                <p className="text-xs text-muted-foreground">
                  Используйте {"{имя}"}, {"{компания}"} и т.д. для персонализации.
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Отмена
              </Button>
              <Button onClick={handleAddTemplate}>Создать</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Управление шаблонами</CardTitle>
          <CardDescription>Создавайте и редактируйте шаблоны сообщений для массовых рассылок</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : templates.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Название</TableHead>
                  <TableHead>Текст</TableHead>
                  <TableHead>Переменные</TableHead>
                  <TableHead>Дата создания</TableHead>
                  <TableHead className="text-right">Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {templates.map((template) => (
                  <TableRow key={template.id}>
                    <TableCell className="font-medium">{template.name}</TableCell>
                    <TableCell className="max-w-xs truncate">{template.content}</TableCell>
                    <TableCell>
                      {template.variables.map((variable, index) => (
                        <span key={index} className="inline-block bg-muted text-xs rounded px-1.5 py-0.5 mr-1 mb-1">
                          {variable}
                        </span>
                      ))}
                    </TableCell>
                    <TableCell>{new Date(template.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setCurrentTemplate(template)
                            setIsEditDialogOpen(true)
                            setRandomizedContent("")
                          }}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Вы уверены?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Это действие нельзя отменить. Шаблон будет удален из системы.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Отмена</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteTemplate(template.id)}>
                                Удалить
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center h-40 text-center">
              <p className="text-muted-foreground mb-4">Нет созданных шаблонов</p>
              <Button onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Создать первый шаблон
              </Button>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <p className="text-sm text-muted-foreground">Всего шаблонов: {templates.length}</p>
          <Button variant="outline" size="sm" onClick={fetchTemplates}>
            Обновить
          </Button>
        </CardFooter>
      </Card>

      {/* Edit Template Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Редактировать шаблон</DialogTitle>
            <DialogDescription>
              Отредактируйте шаблон сообщения и используйте рандомайзер для обхода спам-фильтров.
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="edit">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="edit">Редактирование</TabsTrigger>
              <TabsTrigger value="randomize">Рандомайзер</TabsTrigger>
            </TabsList>
            <TabsContent value="edit" className="space-y-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-name">Название шаблона</Label>
                <Input
                  id="edit-name"
                  value={currentTemplate?.name || ""}
                  onChange={(e) =>
                    currentTemplate &&
                    setCurrentTemplate({
                      ...currentTemplate,
                      name: e.target.value,
                    })
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-content">Текст сообщения</Label>
                <Textarea
                  id="edit-content"
                  rows={8}
                  value={currentTemplate?.content || ""}
                  onChange={(e) =>
                    currentTemplate &&
                    setCurrentTemplate({
                      ...currentTemplate,
                      content: e.target.value,
                      variables: extractVariables(e.target.value),
                    })
                  }
                />
                <p className="text-xs text-muted-foreground">
                  Используйте {"{имя}"}, {"{компания}"} и т.д. для персонализации.
                </p>
              </div>
              <div>
                <Label>Переменные в шаблоне</Label>
                <div className="flex flex-wrap gap-1 mt-2">
                  {currentTemplate?.variables.map((variable, index) => (
                    <span key={index} className="bg-muted text-xs rounded px-2 py-1">
                      {variable}
                    </span>
                  ))}
                  {currentTemplate?.variables.length === 0 && (
                    <span className="text-sm text-muted-foreground">Нет переменных</span>
                  )}
                </div>
              </div>
            </TabsContent>
            <TabsContent value="randomize" className="space-y-4 py-4">
              <div className="flex justify-between items-center mb-4">
                <Label>Рандомизация текста</Label>
                <Button variant="outline" size="sm" onClick={generateRandomizedContent}>
                  <Wand2 className="mr-2 h-4 w-4" />
                  Сгенерировать вариант
                </Button>
              </div>
              <div className="grid gap-4">
                <div>
                  <Label className="mb-2 block">Оригинальный текст</Label>
                  <div className="p-4 rounded-md bg-muted whitespace-pre-wrap">{currentTemplate?.content || ""}</div>
                </div>
                <div>
                  <Label className="mb-2 block">Рандомизированный вариант</Label>
                  <div className="p-4 rounded-md bg-muted whitespace-pre-wrap min-h-[100px]">
                    {randomizedContent || 'Нажмите "Сгенерировать вариант" для создания рандомизированного текста'}
                  </div>
                </div>
                {randomizedContent && (
                  <Button
                    onClick={() =>
                      currentTemplate &&
                      setCurrentTemplate({
                        ...currentTemplate,
                        content: randomizedContent,
                        variables: extractVariables(randomizedContent),
                      })
                    }
                  >
                    Использовать этот вариант
                  </Button>
                )}
              </div>
              <div className="text-sm text-muted-foreground mt-4">
                <p>
                  Рандомайзер заменяет стандартные фразы на синонимы, меняет порядок предложений и добавляет
                  вариативность, чтобы обойти спам-фильтры.
                </p>
              </div>
            </TabsContent>
          </Tabs>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Отмена
            </Button>
            <Button onClick={handleEditTemplate}>Сохранить</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default Messages
