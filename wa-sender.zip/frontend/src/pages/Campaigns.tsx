"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { Input } from "../components/ui/input"
import { Label } from "../components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "../components/ui/alert-dialog"
import { useToast } from "../hooks/use-toast"
import { Loader2, Plus, Trash2, Play, Pause, StopCircle, Eye } from "lucide-react"
import { Progress } from "../components/ui/progress"
import { Badge } from "../components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select"
import { Checkbox } from "../components/ui/checkbox"
import { ScrollArea } from "../components/ui/scroll-area"
import { useSocket } from "../context/SocketContext"

interface Campaign {
  id: string
  name: string
  status: "draft" | "running" | "paused" | "completed" | "failed"
  messageTemplateId: string
  messageTemplateName: string
  totalContacts: number
  sentCount: number
  deliveredCount: number
  failedCount: number
  createdAt: string
  startedAt: string | null
  completedAt: string | null
}

interface MessageTemplate {
  id: string
  name: string
  content: string
  variables: string[]
}

interface Instance {
  id: string
  name: string
  instanceId: string
  status: "active" | "inactive" | "error"
}

const Campaigns = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const [loading, setLoading] = useState(true)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [currentCampaign, setCurrentCampaign] = useState<Campaign | null>(null)
  const [templates, setTemplates] = useState<MessageTemplate[]>([])
  const [instances, setInstances] = useState<Instance[]>([])
  const [newCampaign, setNewCampaign] = useState({
    name: "",
    messageTemplateId: "",
    instanceIds: [] as string[],
    useRandomization: true,
    onlyWhatsappUsers: true,
  })
  const { connected } = useSocket()
  const { toast } = useToast()

  const fetchCampaigns = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/campaigns`)
      if (response.ok) {
        const data = await response.json()
        setCampaigns(data)
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить кампании",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить кампании",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchTemplates = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/messages`)
      if (response.ok) {
        const data = await response.json()
        setTemplates(data)
      }
    } catch (error) {
      console.error("Failed to fetch templates:", error)
    }
  }

  const fetchInstances = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/instances`)
      if (response.ok) {
        const data = await response.json()
        setInstances(data.filter((instance: Instance) => instance.status === "active"))
      }
    } catch (error) {
      console.error("Failed to fetch instances:", error)
    }
  }

  useEffect(() => {
    fetchCampaigns()
    fetchTemplates()
    fetchInstances()

    // Refresh campaigns every 10 seconds
    const interval = setInterval(() => {
      if (connected) {
        fetchCampaigns()
      }
    }, 10000)

    return () => clearInterval(interval)
  }, [toast, connected])

  const handleCreateCampaign = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/campaigns`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newCampaign),
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Кампания создана",
        })
        setIsCreateDialogOpen(false)
        setNewCampaign({
          name: "",
          messageTemplateId: "",
          instanceIds: [],
          useRandomization: true,
          onlyWhatsappUsers: true,
        })
        fetchCampaigns()
      } else {
        const error = await response.json()
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось создать кампанию",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось создать кампанию",
        variant: "destructive",
      })
    }
  }

  const handleDeleteCampaign = async (id: string) => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/campaigns/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Кампания удалена",
        })
        fetchCampaigns()
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось удалить кампанию",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить кампанию",
        variant: "destructive",
      })
    }
  }

  const handleStartCampaign = async (id: string) => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/campaigns/${id}/start`, {
        method: "POST",
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Кампания запущена",
        })
        fetchCampaigns()
      } else {
        const error = await response.json()
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось запустить кампанию",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось запустить кампанию",
        variant: "destructive",
      })
    }
  }

  const handlePauseCampaign = async (id: string) => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/campaigns/${id}/pause`, {
        method: "POST",
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Кампания приостановлена",
        })
        fetchCampaigns()
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось приостановить кампанию",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось приостановить кампанию",
        variant: "destructive",
      })
    }
  }

  const handleStopCampaign = async (id: string) => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/campaigns/${id}/stop`, {
        method: "POST",
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Кампания остановлена",
        })
        fetchCampaigns()
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось остановить кампанию",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось остановить кампанию",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "draft":
        return <Badge variant="outline">Черновик</Badge>
      case "running":
        return <Badge className="bg-green-500">Запущена</Badge>
      case "paused":
        return <Badge variant="secondary">Приостановлена</Badge>
      case "completed":
        return <Badge className="bg-blue-500">Завершена</Badge>
      case "failed":
        return <Badge variant="destructive">Ошибка</Badge>
      default:
        return <Badge variant="outline">Неизвестно</Badge>
    }
  }

  const getProgress = (campaign: Campaign) => {
    if (campaign.totalContacts === 0) return 0
    return Math.round((campaign.sentCount / campaign.totalContacts) * 100)
  }

  const toggleInstanceSelection = (instanceId: string) => {
    setNewCampaign((prev) => {
      if (prev.instanceIds.includes(instanceId)) {
        return {
          ...prev,
          instanceIds: prev.instanceIds.filter((id) => id !== instanceId),
        }
      } else {
        return {
          ...prev,
          instanceIds: [...prev.instanceIds, instanceId],
        }
      }
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Кампании рассылки</h1>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Создать кампанию
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Создать новую кампанию</DialogTitle>
              <DialogDescription>Настройте параметры новой кампании рассылки WhatsApp сообщений</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Название кампании</Label>
                <Input
                  id="name"
                  placeholder="Рассылка клиентам"
                  value={newCampaign.name}
                  onChange={(e) => setNewCampaign({ ...newCampaign, name: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="template">Шаблон сообщения</Label>
                <Select
                  value={newCampaign.messageTemplateId}
                  onValueChange={(value) => setNewCampaign({ ...newCampaign, messageTemplateId: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите шаблон" />
                  </SelectTrigger>
                  <SelectContent>
                    {templates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {templates.length === 0 && (
                  <p className="text-xs text-red-500">Нет доступных шаблонов. Создайте шаблон в разделе "Сообщения".</p>
                )}
              </div>
              <div className="grid gap-2">
                <Label>Инстансы для отправки</Label>
                <Card>
                  <ScrollArea className="h-[150px]">
                    <div className="p-4 space-y-2">
                      {instances.length > 0 ? (
                        instances.map((instance) => (
                          <div key={instance.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={`instance-${instance.id}`}
                              checked={newCampaign.instanceIds.includes(instance.id)}
                              onCheckedChange={() => toggleInstanceSelection(instance.id)}
                            />
                            <Label htmlFor={`instance-${instance.id}`} className="text-sm font-normal cursor-pointer">
                              {instance.name} ({instance.instanceId})
                            </Label>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-red-500">
                          Нет активных инстансов. Добавьте инстанс в разделе "Инстансы".
                        </p>
                      )}
                    </div>
                  </ScrollArea>
                </Card>
                {newCampaign.instanceIds.length === 0 && (
                  <p className="text-xs text-red-500">Выберите хотя бы один инстанс для отправки.</p>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="randomization"
                  checked={newCampaign.useRandomization}
                  onCheckedChange={(checked) => setNewCampaign({ ...newCampaign, useRandomization: !!checked })}
                />
                <Label htmlFor="randomization" className="text-sm font-normal cursor-pointer">
                  Использовать рандомизацию текста
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="whatsapp-only"
                  checked={newCampaign.onlyWhatsappUsers}
                  onCheckedChange={(checked) => setNewCampaign({ ...newCampaign, onlyWhatsappUsers: !!checked })}
                />
                <Label htmlFor="whatsapp-only" className="text-sm font-normal cursor-pointer">
                  Отправлять только пользователям с WhatsApp
                </Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Отмена
              </Button>
              <Button
                onClick={handleCreateCampaign}
                disabled={!newCampaign.name || !newCampaign.messageTemplateId || newCampaign.instanceIds.length === 0}
              >
                Создать
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Управление кампаниями</CardTitle>
          <CardDescription>Создавайте и управляйте кампаниями массовой рассылки WhatsApp сообщений</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : campaigns.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Название</TableHead>
                  <TableHead>Статус</TableHead>
                  <TableHead>Шаблон</TableHead>
                  <TableHead>Прогресс</TableHead>
                  <TableHead>Создана</TableHead>
                  <TableHead className="text-right">Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {campaigns.map((campaign) => (
                  <TableRow key={campaign.id}>
                    <TableCell className="font-medium">{campaign.name}</TableCell>
                    <TableCell>{getStatusBadge(campaign.status)}</TableCell>
                    <TableCell>{campaign.messageTemplateName}</TableCell>
                    <TableCell>
                      <div className="w-[150px] space-y-1">
                        <Progress value={getProgress(campaign)} className="h-2" />
                        <div className="text-xs text-muted-foreground">
                          {campaign.sentCount}/{campaign.totalContacts} отправлено
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{new Date(campaign.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setCurrentCampaign(campaign)
                            setIsViewDialogOpen(true)
                          }}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {campaign.status === "draft" && (
                          <Button variant="default" size="sm" onClick={() => handleStartCampaign(campaign.id)}>
                            <Play className="h-4 w-4" />
                          </Button>
                        )}
                        {campaign.status === "running" && (
                          <>
                            <Button variant="outline" size="sm" onClick={() => handlePauseCampaign(campaign.id)}>
                              <Pause className="h-4 w-4" />
                            </Button>
                            <Button variant="destructive" size="sm" onClick={() => handleStopCampaign(campaign.id)}>
                              <StopCircle className="h-4 w-4" />
                            </Button>
                          </>
                        )}
                        {campaign.status === "paused" && (
                          <>
                            <Button variant="default" size="sm" onClick={() => handleStartCampaign(campaign.id)}>
                              <Play className="h-4 w-4" />
                            </Button>
                            <Button variant="destructive" size="sm" onClick={() => handleStopCampaign(campaign.id)}>
                              <StopCircle className="h-4 w-4" />
                            </Button>
                          </>
                        )}
                        {(campaign.status === "draft" ||
                          campaign.status === "completed" ||
                          campaign.status === "failed") && (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="destructive" size="sm">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Вы уверены?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Это действие нельзя отменить. Кампания будет удалена из системы.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Отмена</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteCampaign(campaign.id)}>
                                  Удалить
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center h-40 text-center">
              <p className="text-muted-foreground mb-4">Нет созданных кампаний</p>
              <Button onClick={() => setIsCreateDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Создать первую кампанию
              </Button>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <p className="text-sm text-muted-foreground">Всего кампаний: {campaigns.length}</p>
        </CardFooter>
      </Card>

      {/* View Campaign Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Детали кампании</DialogTitle>
            <DialogDescription>Подробная информация о кампании рассылки</DialogDescription>
          </DialogHeader>
          {currentCampaign && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium">Название</h4>
                  <p className="text-sm">{currentCampaign.name}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium">Статус</h4>
                  <div className="mt-1">{getStatusBadge(currentCampaign.status)}</div>
                </div>
                <div>
                  <h4 className="text-sm font-medium">Шаблон</h4>
                  <p className="text-sm">{currentCampaign.messageTemplateName}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium">Всего контактов</h4>
                  <p className="text-sm">{currentCampaign.totalContacts}</p>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium">Прогресс отправки</h4>
                <Progress value={getProgress(currentCampaign)} className="h-2" />
                <div className="grid grid-cols-3 gap-2 text-center text-sm">
                  <div>
                    <p className="font-medium">{currentCampaign.sentCount}</p>
                    <p className="text-xs text-muted-foreground">Отправлено</p>
                  </div>
                  <div>
                    <p className="font-medium text-green-500">{currentCampaign.deliveredCount}</p>
                    <p className="text-xs text-muted-foreground">Доставлено</p>
                  </div>
                  <div>
                    <p className="font-medium text-red-500">{currentCampaign.failedCount}</p>
                    <p className="text-xs text-muted-foreground">Ошибки</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium">Создана</h4>
                  <p className="text-sm">{new Date(currentCampaign.createdAt).toLocaleString()}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium">Запущена</h4>
                  <p className="text-sm">
                    {currentCampaign.startedAt ? new Date(currentCampaign.startedAt).toLocaleString() : "-"}
                  </p>
                </div>
                <div className="col-span-2">
                  <h4 className="text-sm font-medium">Завершена</h4>
                  <p className="text-sm">
                    {currentCampaign.completedAt ? new Date(currentCampaign.completedAt).toLocaleString() : "-"}
                  </p>
                </div>
              </div>

              {currentCampaign.status === "running" && (
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      handlePauseCampaign(currentCampaign.id)
                      setIsViewDialogOpen(false)
                    }}
                  >
                    <Pause className="mr-2 h-4 w-4" />
                    Приостановить
                  </Button>
                  <Button
                    variant="destructive"
                    className="flex-1"
                    onClick={() => {
                      handleStopCampaign(currentCampaign.id)
                      setIsViewDialogOpen(false)
                    }}
                  >
                    <StopCircle className="mr-2 h-4 w-4" />
                    Остановить
                  </Button>
                </div>
              )}

              {currentCampaign.status === "paused" && (
                <div className="flex gap-2">
                  <Button
                    variant="default"
                    className="flex-1"
                    onClick={() => {
                      handleStartCampaign(currentCampaign.id)
                      setIsViewDialogOpen(false)
                    }}
                  >
                    <Play className="mr-2 h-4 w-4" />
                    Возобновить
                  </Button>
                  <Button
                    variant="destructive"
                    className="flex-1"
                    onClick={() => {
                      handleStopCampaign(currentCampaign.id)
                      setIsViewDialogOpen(false)
                    }}
                  >
                    <StopCircle className="mr-2 h-4 w-4" />
                    Остановить
                  </Button>
                </div>
              )}

              {currentCampaign.status === "draft" && (
                <Button
                  className="w-full"
                  onClick={() => {
                    handleStartCampaign(currentCampaign.id)
                    setIsViewDialogOpen(false)
                  }}
                >
                  <Play className="mr-2 h-4 w-4" />
                  Запустить кампанию
                </Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default Campaigns
