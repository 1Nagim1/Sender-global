"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table"
import { useToast } from "../hooks/use-toast"
import { Loader2, RefreshCw, BarChart3, PieChart } from "lucide-react"
import { Progress } from "../components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs"

interface InstanceStats {
  id: string
  instanceId: string
  name: string
  totalMessages: number
  deliveredMessages: number
  failedMessages: number
  deliveryRate: number
}

interface DailyStats {
  date: string
  totalMessages: number
  deliveredMessages: number
  failedMessages: number
}

const Analytics = () => {
  const [instanceStats, setInstanceStats] = useState<InstanceStats[]>([])
  const [dailyStats, setDailyStats] = useState<DailyStats[]>([])
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState("7d")
  const { toast } = useToast()

  const fetchAnalytics = async () => {
    setLoading(true)
    try {
      const [instanceResponse, dailyResponse] = await Promise.all([
        fetch(`${import.meta.env.VITE_API_URL}/api/analytics/instances?timeRange=${timeRange}`),
        fetch(`${import.meta.env.VITE_API_URL}/api/analytics/daily?timeRange=${timeRange}`),
      ])

      if (instanceResponse.ok && dailyResponse.ok) {
        const instanceData = await instanceResponse.json()
        const dailyData = await dailyResponse.json()
        setInstanceStats(instanceData)
        setDailyStats(dailyData)
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить аналитику",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить аналитику",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchAnalytics()
  }, [timeRange, toast])

  // Calculate totals
  const totalMessages = instanceStats.reduce((sum, instance) => sum + instance.totalMessages, 0)
  const totalDelivered = instanceStats.reduce((sum, instance) => sum + instance.deliveredMessages, 0)
  const totalFailed = instanceStats.reduce((sum, instance) => sum + instance.failedMessages, 0)
  const overallDeliveryRate = totalMessages > 0 ? Math.round((totalDelivered / totalMessages) * 100) : 0

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit" })
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Аналитика</h1>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Выберите период" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Последние 7 дней</SelectItem>
              <SelectItem value="30d">Последние 30 дней</SelectItem>
              <SelectItem value="90d">Последние 90 дней</SelectItem>
              <SelectItem value="all">За все время</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" onClick={fetchAnalytics}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Всего сообщений</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalMessages}</div>
            <p className="text-xs text-muted-foreground">За выбранный период</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Доставлено</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalDelivered}</div>
            <p className="text-xs text-muted-foreground">За выбранный период</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Не доставлено</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalFailed}</div>
            <p className="text-xs text-muted-foreground">За выбранный период</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Процент доставки</CardTitle>
            <PieChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overallDeliveryRate}%</div>
            <Progress value={overallDeliveryRate} className="h-2 mt-2" />
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="instances">
        <TabsList>
          <TabsTrigger value="instances">По инстансам</TabsTrigger>
          <TabsTrigger value="daily">По дням</TabsTrigger>
        </TabsList>
        <TabsContent value="instances">
          <Card>
            <CardHeader>
              <CardTitle>Статистика по инстансам</CardTitle>
              <CardDescription>Детальная статистика отправки сообщений по каждому инстансу</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center items-center h-40">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : instanceStats.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Инстанс</TableHead>
                      <TableHead>ID инстанса</TableHead>
                      <TableHead>Всего</TableHead>
                      <TableHead>Доставлено</TableHead>
                      <TableHead>Не доставлено</TableHead>
                      <TableHead>% доставки</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {instanceStats.map((instance) => (
                      <TableRow key={instance.id}>
                        <TableCell className="font-medium">{instance.name}</TableCell>
                        <TableCell>{instance.instanceId}</TableCell>
                        <TableCell>{instance.totalMessages}</TableCell>
                        <TableCell>{instance.deliveredMessages}</TableCell>
                        <TableCell>{instance.failedMessages}</TableCell>
                        <TableCell>
                          <div className="w-[100px] space-y-1">
                            <Progress value={instance.deliveryRate} className="h-2" />
                            <div className="text-xs text-right">{instance.deliveryRate}%</div>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center h-40 text-center">
                  <p className="text-muted-foreground">Нет данных за выбранный период</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="daily">
          <Card>
            <CardHeader>
              <CardTitle>Ежедневная статистика</CardTitle>
              <CardDescription>Статистика отправки сообщений по дням</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center items-center h-40">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : dailyStats.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Дата</TableHead>
                      <TableHead>Всего</TableHead>
                      <TableHead>Доставлено</TableHead>
                      <TableHead>Не доставлено</TableHead>
                      <TableHead>% доставки</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dailyStats.map((day) => {
                      const deliveryRate =
                        day.totalMessages > 0 ? Math.round((day.deliveredMessages / day.totalMessages) * 100) : 0

                      return (
                        <TableRow key={day.date}>
                          <TableCell className="font-medium">{formatDate(day.date)}</TableCell>
                          <TableCell>{day.totalMessages}</TableCell>
                          <TableCell>{day.deliveredMessages}</TableCell>
                          <TableCell>{day.failedMessages}</TableCell>
                          <TableCell>
                            <div className="w-[100px] space-y-1">
                              <Progress value={deliveryRate} className="h-2" />
                              <div className="text-xs text-right">{deliveryRate}%</div>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center h-40 text-center">
                  <p className="text-muted-foreground">Нет данных за выбранный период</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default Analytics
