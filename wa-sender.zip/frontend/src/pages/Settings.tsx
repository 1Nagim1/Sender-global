"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { Input } from "../components/ui/input"
import { Label } from "../components/ui/label"
import { useToast } from "../hooks/use-toast"
import { Loader2, Save } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs"
import { Switch } from "../components/ui/switch"
import { Slider } from "../components/ui/slider"

interface Settings {
  messageDelay: {
    min: number
    max: number
  }
  retryAttempts: number
  checkWhatsappBeforeSending: boolean
  logLevel: string
  webhookUrl: string
}

const Settings = () => {
  const [settings, setSettings] = useState<Settings>({
    messageDelay: {
      min: 1000,
      max: 3000,
    },
    retryAttempts: 3,
    checkWhatsappBeforeSending: true,
    logLevel: "info",
    webhookUrl: "",
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const { toast } = useToast()

  const fetchSettings = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/settings`)
      if (response.ok) {
        const data = await response.json()
        setSettings(data)
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить настройки",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить настройки",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchSettings()
  }, [toast])

  const handleSaveSettings = async () => {
    setSaving(true)
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/settings`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(settings),
      })

      if (response.ok) {
        toast({
          title: "Успешно",
          description: "Настройки сохранены",
        })
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось сохранить настройки",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить настройки",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  const handleDelayChange = (values: number[]) => {
    setSettings({
      ...settings,
      messageDelay: {
        min: values[0],
        max: values[1],
      },
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Настройки</h1>
        <Button onClick={handleSaveSettings} disabled={saving}>
          {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
          Сохранить
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-40">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <Tabs defaultValue="general">
          <TabsList>
            <TabsTrigger value="general">Основные</TabsTrigger>
            <TabsTrigger value="advanced">Расширенные</TabsTrigger>
            <TabsTrigger value="webhooks">Вебхуки</TabsTrigger>
          </TabsList>
          <TabsContent value="general">
            <Card>
              <CardHeader>
                <CardTitle>Основные настройки</CardTitle>
                <CardDescription>Настройте основные параметры работы приложения</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label>Задержка между сообщениями (мс)</Label>
                    <div className="pt-6 pb-2">
                      <Slider
                        defaultValue={[settings.messageDelay.min, settings.messageDelay.max]}
                        min={500}
                        max={10000}
                        step={100}
                        onValueChange={handleDelayChange}
                      />
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Мин: {settings.messageDelay.min} мс</span>
                      <span>Макс: {settings.messageDelay.max} мс</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      Случайная задержка между отправкой сообщений для избежания блокировок
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="retryAttempts">Количество попыток отправки</Label>
                    <Input
                      id="retryAttempts"
                      type="number"
                      min={1}
                      max={10}
                      value={settings.retryAttempts}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          retryAttempts: Number.parseInt(e.target.value),
                        })
                      }
                    />
                    <p className="text-xs text-muted-foreground">
                      Сколько раз система будет пытаться отправить сообщение в случае ошибки
                    </p>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="check-whatsapp">Проверять наличие WhatsApp</Label>
                      <p className="text-xs text-muted-foreground">
                        Проверять наличие WhatsApp у получателя перед отправкой
                      </p>
                    </div>
                    <Switch
                      id="check-whatsapp"
                      checked={settings.checkWhatsappBeforeSending}
                      onCheckedChange={(checked) =>
                        setSettings({
                          ...settings,
                          checkWhatsappBeforeSending: checked,
                        })
                      }
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="advanced">
            <Card>
              <CardHeader>
                <CardTitle>Расширенные настройки</CardTitle>
                <CardDescription>Настройте расширенные параметры работы приложения</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="logLevel">Уровень логирования</Label>
                  <select
                    id="logLevel"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    value={settings.logLevel}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        logLevel: e.target.value,
                      })
                    }
                  >
                    <option value="error">Только ошибки</option>
                    <option value="warn">Предупреждения и ошибки</option>
                    <option value="info">Информационные сообщения</option>
                    <option value="debug">Отладочная информация</option>
                  </select>
                  <p className="text-xs text-muted-foreground">Уровень детализации логов системы</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="webhooks">
            <Card>
              <CardHeader>
                <CardTitle>Настройки вебхуков</CardTitle>
                <CardDescription>Настройте URL для получения уведомлений о событиях</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="webhookUrl">URL вебхука</Label>
                  <Input
                    id="webhookUrl"
                    placeholder="https://example.com/webhook"
                    value={settings.webhookUrl}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        webhookUrl: e.target.value,
                      })
                    }
                  />
                  <p className="text-xs text-muted-foreground">
                    URL, на который будут отправляться уведомления о событиях (отправка, доставка, ошибки)
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <p className="text-sm text-muted-foreground">
                  Система будет отправлять POST-запросы с данными о событиях на указанный URL
                </p>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}

export default Settings
